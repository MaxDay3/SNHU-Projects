#Max Day
#Project 3

import os

# Function to read the input file and count the frequency of items
def read_items(filename):
    frequency = {}
    with open(filename, 'r') as file:
        for line in file:
            item = line.strip()
            if item in frequency:
                frequency[item] += 1
            else:
                frequency[item] = 1
    return frequency

# Function to handle Menu Option One
def item_frequency(frequency):
    item = input("Enter the item you want to look for: ")
    count = frequency.get(item, 0)
    print(f"{item} was purchased {count} time(s).")

# Function to handle Menu Option Two
def print_all_frequencies(frequency):
    for item, count in frequency.items():
        print(f"{item} {count}")

# Function to handle Menu Option Three
def print_histogram(frequency):
    for item, count in frequency.items():
        print(f"{item} {'*' * count}")

# Function to handle Menu Option Four
def save_to_file(frequency, filename='frequency.dat'):
    with open(filename, 'w') as file:
        for item, count in frequency.items():
            file.write(f"{item} {count}\n")
    print(f"Data has been saved to {filename}")

# Main function to display the menu and handle user input
def main():
    input_filename = 'CS210_Project_Three_Input_File.txt'
    if not os.path.exists(input_filename):
        print(f"Error: {input_filename} not found.")
        return
    
    frequency = read_items(input_filename)
    
    while True:
        print("\nMenu:")
        print("1. Look up frequency of a specific item")
        print("2. Print all item frequencies")
        print("3. Print histogram of item frequencies")
        print("4. Exit and save data to file")
        
        choice = input("Enter your choice: ")
        
        if choice == '1':
            item_frequency(frequency)
        elif choice == '2':
            print_all_frequencies(frequency)
        elif choice == '3':
            print_histogram(frequency)
        elif choice == '4':
            save_to_file(frequency)
            break
        else:
            print("Invalid choice. Please enter a number between 1 and 4.")

# Execute the program
if __name__ == "__main__":
    main()
